import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./generated-tests",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: "list",
  use: { headless: true },
});
