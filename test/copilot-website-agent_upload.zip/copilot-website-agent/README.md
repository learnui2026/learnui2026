# GitHub Copilot Website Testing Agent

This project replaces the Gemini API call in the supplied website-testing agent with the official GitHub Copilot SDK. It keeps Playwright website inspection, terminal-provided test requirements, and generated test output at `generated-tests/website.spec.ts`.

## Prerequisites

- Node.js (current LTS recommended)
- GitHub Copilot access that permits use of the Copilot SDK
- GitHub Copilot CLI installed and authenticated using your organization's approved method
- Windows PowerShell, macOS Terminal, or Linux shell

Follow the official setup instructions: https://docs.github.com/en/copilot/how-tos/copilot-sdk/setup

The VS Code Copilot extension alone does not necessarily configure authentication for a standalone Node.js program. Company-managed environments may restrict SDK usage; follow your administrator's policy.

## Install (Windows PowerShell)

```powershell
npm install
npx playwright install chromium
Copy-Item .env.example .env
```

`COPILOT_MODEL=auto` lets Copilot choose an available model. You can change it to a model supported by your Copilot account and organization. No Gemini API key is used.

## Run the agent

```powershell
npm start
```

Enter a URL, then optional instructions such as:

`Find the enquiry form, fill the name field with Host, fill the message field with How are you?, submit it only if this is a safe test environment, and verify the success message.`

The generated test file is written to `generated-tests/website.spec.ts`.

## Run generated tests

Review the generated file first. Then run:

```powershell
npm run test:generated
```

or:

```powershell
npx playwright test generated-tests/website.spec.ts
```

## Troubleshooting

- **Copilot CLI/authentication error:** install/sign in to Copilot CLI using the official setup guide and check organization policies.
- **Access or model error:** check your Copilot entitlement, selected model, and company policy. This project does not silently fall back to Gemini.
- **Website timeout:** retry with a reachable URL; some websites block automated browsers.
- **Generated tests fail:** inspect the generated test file and the Playwright error before rerunning. The agent does not claim tests passed just because generation succeeded.

## Safety

Website inspection is read-only. Generated tests may interact with forms, so review them before execution. Do not run generated tests against live services if they may send real messages, change accounts, make purchases, or perform other consequential actions.
