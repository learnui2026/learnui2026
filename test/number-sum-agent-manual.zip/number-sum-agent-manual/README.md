# Manual Number-Sum AI Agent (TypeScript)

This project uses the OpenAI API directly. It does **not** use the OpenAI Agents SDK or another agent framework.

Dependencies:
- `openai`: official OpenAI API client
- `dotenv`: loads `.env`
- TypeScript/tsx packages are only for development and running TypeScript.

## Requirements
- Node.js 20+
- An OpenAI API key with API access

## Install
```bash
npm install
```

## Configure API key
Copy `.env.example` to `.env`.

Windows PowerShell:
```powershell
Copy-Item .env.example .env
```

macOS/Linux:
```bash
cp .env.example .env
```

Edit `.env`:
```env
OPENAI_API_KEY=your_real_api_key_here
OPENAI_MODEL=gpt-5.5
```
Keep `.env` private and never commit it to GitHub. If your API account does not have access to the configured model, set `OPENAI_MODEL` to an available model.

## Run
```bash
npm start
```

Paste a multiline paragraph, for example:
```text
I bought 3 apples, 12 bananas, and 5 oranges.
The bill was 250.50.
I received a refund of -20.
```

Finish input with Ctrl+Z then Enter on Windows, or Ctrl+D on macOS/Linux.

The model should extract `3, 12, 5, 250.50, -20`, call `calculateSum`, and report `250.50`.

## Build and run compiled JavaScript
```bash
npm run build
npm run start:build
```

## Where is the agent?
Everything is in `src/agent.ts`.

- `instructions` tells the model how to behave.
- `tools` describes `calculateSum` to the API.
- `calculateSum()` is the actual TypeScript function that performs arithmetic.
- `runAgent()` contains the manual agent loop.

The loop calls the model, checks `assistantMessage.tool_calls`, validates the arguments, executes `calculateSum`, sends a `role: "tool"` message with the matching `tool_call_id`, and calls the model again. When the model returns a normal message without tool calls, the loop prints the final answer.

No Agents SDK is used.

## Important extraction note
The model decides which numeric values count as numbers, so dates, phone numbers, IDs, percentages, or numbers written as words can be ambiguous. This starter version asks the model to extract values represented as digits; it does not guarantee perfect extraction from every paragraph.
