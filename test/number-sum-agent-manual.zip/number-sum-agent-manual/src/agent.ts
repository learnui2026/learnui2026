
import "dotenv/config";
import { GoogleGenAI } from "@google/genai";
import {
  chromium,
  type Page,
  type Locator,
} from "playwright";
import {
  mkdir,
  writeFile,
} from "node:fs/promises";
import * as readline from "node:readline/promises";
import { stdin, stdout } from "node:process";
import path from "node:path";

const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

if (!API_KEY) {
  throw new Error(
    "GEMINI_API_KEY is missing. Add it to your .env file."
  );
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

type ElementInfo = {
  tag: string;
  text: string;
  id: string | null;
  name: string | null;
  type: string | null;
  role: string | null;
  ariaLabel: string | null;
  placeholder: string | null;
  title: string | null;
  href?: string | null;
  required?: boolean;
  disabled?: boolean;
};

type FormInfo = {
  id: string | null;
  name: string | null;
  action: string | null;
  method: string | null;
  text: string;
  fields: ElementInfo[];
};

type WebsiteInfo = {
  url: string;
  finalUrl: string;
  title: string;
  headings: ElementInfo[];
  forms: FormInfo[];
  fieldsOutsideForms: ElementInfo[];
  buttons: ElementInfo[];
  links: ElementInfo[];
  pageText: string;
  inspectionWarnings: string[];
};

const MAX_ELEMENTS = 60;
const MAX_TEXT_LENGTH = 12000;

function shorten(
  value: string | null | undefined,
  max = 500
): string {
  return (value ?? "").trim().slice(0, max);
}

/**
 * Collects actual element attributes without assuming
 * particular field names, placeholders, or button labels.
 */
async function readElements(
  root: Page | Locator,
  selector: string,
  limit = MAX_ELEMENTS
): Promise<ElementInfo[]> {
  const collection = root.locator(selector);
  const count = Math.min(await collection.count(), limit);
  const results: ElementInfo[] = [];

  for (let i = 0; i < count; i++) {
    const element = collection.nth(i);

    try {
      const tag = await element.evaluate(
        (node) => node.tagName.toLowerCase()
      ).catch(() => "");

      const [
        text,
        id,
        name,
        type,
        role,
        ariaLabel,
        placeholder,
        title,
        href,
        required,
        disabled,
      ] = await Promise.all([
        element.innerText().catch(() => ""),
        element.getAttribute("id").catch(() => null),
        element.getAttribute("name").catch(() => null),
        element.getAttribute("type").catch(() => null),
        element.getAttribute("role").catch(() => null),
        element.getAttribute("aria-label").catch(() => null),
        element.getAttribute("placeholder").catch(() => null),
        element.getAttribute("title").catch(() => null),
        element.getAttribute("href").catch(() => null),
        element.getAttribute("required").catch(() => null),
        element.getAttribute("disabled").catch(() => null),
      ]);

      results.push({
        tag,
        text: shorten(text, 300),
        id,
        name,
        type,
        role,
        ariaLabel,
        placeholder,
        title,
        href,
        required: required !== null,
        disabled: disabled !== null,
      });
    } catch {
      // The element may disappear while the page is loading.
      continue;
    }
  }

  return results;
}

async function inspectForms(page: Page): Promise<FormInfo[]> {
  const forms = page.locator("form");
  const count = Math.min(await forms.count(), 30);
  const results: FormInfo[] = [];

  for (let i = 0; i < count; i++) {
    const form = forms.nth(i);

    try {
      const [
        id,
        name,
        action,
        method,
        text,
        fields,
      ] = await Promise.all([
        form.getAttribute("id").catch(() => null),
        form.getAttribute("name").catch(() => null),
        form.getAttribute("action").catch(() => null),
        form.getAttribute("method").catch(() => null),
        form.innerText().catch(() => ""),
        readElements(
          form,
          "input, textarea, select, button",
          50
        ),
      ]);

      results.push({
        id,
        name,
        action,
        method,
        text: shorten(text, 1500),
        fields,
      });
    } catch {
      continue;
    }
  }

  return results;
}

async function inspectWebsite(url: string): Promise<WebsiteInfo> {
  const browser = await chromium.launch({ headless: true });

  const page = await browser.newPage({
    viewport: { width: 1365, height: 900 },
  });

  const warnings: string[] = [];

  try {
    console.log("\nInspecting website...");
    console.log("URL:", url);

    const response = await page.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: 45000,
    });

    if (response && response.status() >= 400) {
      warnings.push(
        `Initial navigation returned HTTP ${response.status()}.`
      );
    }

    await page.waitForLoadState("load", {
      timeout: 10000,
    }).catch(() => undefined);

    await page.waitForTimeout(1000);

    const title = await page.title().catch(() => "");
    const finalUrl = page.url();

    const [
      headings,
      forms,
      allFields,
      buttons,
      links,
      pageText,
    ] = await Promise.all([
      readElements(page, "h1, h2, h3, h4, h5, h6", 50),
      inspectForms(page),
      readElements(page, "input, textarea, select"),
      readElements(
        page,
        'button, input[type="submit"], input[type="button"], [role="button"]'
      ),
      readElements(page, "a[href]"),
      page.locator("body").innerText().catch(() => ""),
    ]);

    const fieldsOutsideForms: ElementInfo[] = [];
    const fieldLocator = page.locator("input, textarea, select");
    const fieldCount = Math.min(
      await fieldLocator.count(),
      MAX_ELEMENTS
    );

    for (let i = 0; i < fieldCount; i++) {
      const field = fieldLocator.nth(i);

      const belongsToForm = await field.evaluate(
        (element) => element.closest("form") !== null
      ).catch(() => true);

      if (!belongsToForm && allFields[i]) {
        fieldsOutsideForms.push(allFields[i]);
      }
    }

    if (allFields.length >= MAX_ELEMENTS) {
      warnings.push(
        `Field inspection was limited to ${MAX_ELEMENTS} elements.`
      );
    }

    if (forms.length === 0) {
      warnings.push(
        "No standard HTML forms were detected. The website may use custom controls."
      );
    }

    return {
      url,
      finalUrl,
      title,
      headings,
      forms,
      fieldsOutsideForms,
      buttons,
      links,
      pageText: shorten(pageText, MAX_TEXT_LENGTH),
      inspectionWarnings: warnings,
    };
  } finally {
    await browser.close();
  }
}

/**
 * Combines automatic website testing with additional
 * test requirements supplied by the user.
 */
function buildGenerationPrompt(
  info: WebsiteInfo,
  userRequirements: string
): string {
  return `
You are an expert TypeScript and Playwright test-generation agent.

Generate a complete Playwright test file for the inspected website.

WEBSITE INSPECTION DATA:
${JSON.stringify(info, null, 2)}

ADDITIONAL TEST REQUIREMENTS FROM THE USER:
${
  userRequirements.trim() ||
  "No additional requirements provided. Generate automatic tests only."
}

CORE REQUIREMENTS:

1. PRESERVE AUTOMATIC TEST GENERATION
- Generate useful tests from the website inspection data.
- Include appropriate page-load, heading, navigation, and control tests.
- Do not replace the automatic tests with only user-requested tests.
- Add the requested tests alongside the automatic tests.
- Avoid duplicate tests where the same behavior is already covered.

2. NO HARDCODED WEBSITE ASSUMPTIONS
- Do not assume particular field names, placeholders, labels,
  headings, forms, buttons, or links exist.
- Use actual attributes and structure from the inspection data.
- Do not invent website-specific IDs, labels, text, or selectors.
- The inspection code is generic; generated locators may use
  observed website-specific values.
- If the user requests an element that cannot be found, do not
  invent it. Report the limitation in a test comment or use
  test.skip() with a clear reason.

3. LOCATOR UNIQUENESS
- Prefer reliable observed IDs, names, accessible labels, roles,
  placeholders, and other grounded locators.
- Before acting on a locator that may match multiple elements,
  verify its count.
- Scope ambiguous fields to their correct form or section using
  observed attributes and structure.
- Never use first() or nth() just to conceal ambiguity.
- If the correct element cannot be identified reliably, report
  the ambiguity instead of guessing.
- Do not assume every website has an email field or contact form.

4. USER-REQUESTED INTERACTIONS
- Interpret the user's instructions and generate additional
  tests that address those requirements.
- If the user asks to fill a field, identify the corresponding
  observed field and use appropriate test data.
- If the user asks to test a form submission, identify the actual
  form and submit control before generating the test.
- If the user provides test values, use them as test inputs.
- If values are missing, use clearly identified synthetic test
  data where appropriate.
- If the request cannot be fulfilled from the inspection data,
  explain the limitation in a code comment or skip the test.
- Do not claim an action succeeded unless the test verifies it.

5. SUBMISSION AND SAFETY
- The inspection phase must remain read-only.
- Filling fields is allowed in generated tests when appropriate.
- Only generate form-submission tests when explicitly requested
  by the user or when submission is demonstrably safe.
- A live form may send a real message, create an account, modify
  data, or trigger another real-world action.
- For live websites, do not submit forms that initiate payments,
  purchases, account changes, or other consequential operations.
- For potentially consequential submissions, generate a test
  that requires a designated test environment or safe mock
  rather than executing the action against a live service.
- Do not invent authentication, token prompts, or hidden dialogs.
- Never hardcode passwords, API keys, or authentication tokens.

6. TEST QUALITY
- Use @playwright/test.
- Use test.describe and separate test cases where appropriate.
- Use assertions based on actual inspection evidence.
- Test required-field attributes only when the evidence supports it.
- Avoid brittle assertions based on large blocks of page text.
- Avoid fixed waits as a substitute for assertions.
- Do not use page.evaluate() or page.evaluateAll() in generated tests.
- Do not import unavailable helper files.
- Make each test independent where practical.

7. OUTPUT
- Return only complete, executable TypeScript source code.
- Do not include Markdown fences or explanatory prose.
- Use the inspected website URL in the generated tests.
- Ensure the output can be saved as a .spec.ts file.
`;
}

function extractTypeScript(response: string): string {
  const trimmed = response.trim();

  const fenced = trimmed.match(
    /^\s*\`\`\`(?:typescript|ts)?\s*\n([\s\S]*?)\n\`\`\`\s*$/i
  );

  return (fenced ? fenced[1] : trimmed).trim() + "\n";
}

async function generateTests(
  info: WebsiteInfo,
  userRequirements: string
): Promise<string> {
  console.log(
    "\nAsking Gemini to generate automatic and requested tests..."
  );

  const prompt = buildGenerationPrompt(info, userRequirements);

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: prompt,
  });

  const generatedCode = response.text?.trim();

  if (!generatedCode) {
    throw new Error(
      "Gemini returned an empty response. Try again."
    );
  }

  const code = extractTypeScript(generatedCode);

  if (
    !code.includes("@playwright/test") ||
    !/\btest\s*\(/.test(code)
  ) {
    throw new Error(
      "Gemini did not return recognizable Playwright test code. " +
      "No test file was saved."
    );
  }

  return code;
}

async function main(): Promise<void> {
  const rl = readline.createInterface({
    input: stdin,
    output: stdout,
  });

  try {
    const urlInput = await rl.question(
      "Enter the website URL to inspect: "
    );

    const url = urlInput.trim();

    let parsedUrl: URL;

    try {
      parsedUrl = new URL(url);
    } catch {
      throw new Error(
        "Invalid URL. Enter a complete URL, such as https://example.com"
      );
    }

    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      throw new Error(
        "Only HTTP and HTTPS URLs are supported."
      );
    }

    const userRequirements = await rl.question(
      "\nWhat additional tests do you want?\n" +
      "Describe fields, values, actions, or form submissions.\n" +
      "Press Enter to generate automatic tests only:\n> "
    );

    const info = await inspectWebsite(parsedUrl.toString());

    console.log("\nWebsite inspection complete.");
    console.log("Title:", info.title || "(no title found)");
    console.log("Final URL:", info.finalUrl);
    console.log("Headings found:", info.headings.length);
    console.log("Forms found:", info.forms.length);

    console.log(
      "Fields inside forms:",
      info.forms.reduce(
        (total, form) => total + form.fields.length,
        0
      )
    );

    console.log(
      "Fields outside forms:",
      info.fieldsOutsideForms.length
    );

    console.log("Buttons found:", info.buttons.length);
    console.log("Links found:", info.links.length);

    if (info.inspectionWarnings.length > 0) {
      console.log("\nInspection warnings:");

      for (const warning of info.inspectionWarnings) {
        console.log("-", warning);
      }
    }

    const code = await generateTests(info, userRequirements);

    const outputDirectory = path.resolve("generated-tests");
    const outputFile = path.join(
      outputDirectory,
      "website.spec.ts"
    );

    await mkdir(outputDirectory, { recursive: true });
    await writeFile(outputFile, code, "utf8");

    console.log("\nTest generation complete.");
    console.log("Generated file:", outputFile);
    console.log(
      "\nReview the generated tests before running them."
    );
    console.log("\nTo run the tests, execute:");
    console.log(
      "npx playwright test generated-tests/website.spec.ts"
    );
  } finally {
    rl.close();
  }
}

main().catch((error: unknown) => {
  const message =
    error instanceof Error ? error.message : String(error);

  console.error("\nAgent failed:", message);
  process.exitCode = 1;
});
