import { test, expect } from '@playwright/test';

const TARGET_URL = 'https://learnui2026.github.io/learnui2026/';

test.describe('Paid Course Enquiry Application', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(TARGET_URL);
  });

  test('should load the page with correct title and main headings', async ({ page }) => {
    await expect(page).toHaveTitle('Paid Course Enquiry');

    const mainHeading = page.locator('h1');
    await expect(mainHeading).toHaveText('Enquiry Board');

    const sendEnquiryHeading = page.getByRole('heading', { name: 'SEND Enquiry', level: 2 });
    await expect(sendEnquiryHeading).toBeVisible();

    const allMessagesHeading = page.getByRole('heading', { name: 'All Messages', level: 2 });
    await expect(allMessagesHeading).toBeVisible();

    const noMessagesHeading = page.getByRole('heading', { name: 'No messages loaded', level: 3 });
    await expect(noMessagesHeading).toBeVisible();
  });

  test('should display required input controls and buttons', async ({ page }) => {
    const senderInput = page.locator('#sender');
    await expect(senderInput).toBeVisible();
    await expect(senderInput).toHaveAttribute('placeholder', 'Enter your name');

    const messageInput = page.locator('#message');
    await expect(messageInput).toBeVisible();
    await expect(messageInput).toHaveAttribute('placeholder', 'Write your message...');

    const sendButton = page.locator('#sendButton');
    await expect(sendButton).toBeVisible();
    await expect(sendButton).toHaveText(/Send Enquiry/);

    const fetchButton = page.locator('#fetchButton');
    await expect(fetchButton).toBeVisible();
    await expect(fetchButton).toHaveText(/Fetch All Enquiry Official Use Only/);
  });

  test('should display the Google Meet join link with correct target', async ({ page }) => {
    const meetLink = page.getByRole('link', { name: '🎥 Join Meet With Host' });
    await expect(meetLink).toBeVisible();
    await expect(meetLink).toHaveAttribute('href', 'https://meet.google.com/vse-fpwh-fcd');
  });

  test('should fill enquiry details as Host and handle token prompt dialog on send', async ({ page }) => {
    const senderInput = page.locator('#sender');
    const messageInput = page.locator('#message');
    const sendButton = page.locator('#sendButton');

    // Token can be provided via environment variable ENQUIRY_TOKEN or default test token
    const token = process.env.ENQUIRY_TOKEN || 'TEST_TOKEN';
    let dialogHandled = false;

    // Listen for potential prompt/alert dialogs triggered upon clicking send
    page.on('dialog', async (dialog) => {
      dialogHandled = true;
      if (dialog.type() === 'prompt') {
        await dialog.accept(token);
      } else {
        await dialog.accept();
      }
    });

    // Enter requested sender name and message
    await senderInput.fill('Host');
    await expect(senderInput).toHaveValue('Host');

    await messageInput.fill('HOW ARE YOU BISHNU');
    await expect(messageInput).toHaveValue('HOW ARE YOU BISHNU');

    // Click Send Enquiry
    await sendButton.click();

    // Verify inputs remain accessible or reflect user action
    await expect(sendButton).toBeEnabled();
  });
});
